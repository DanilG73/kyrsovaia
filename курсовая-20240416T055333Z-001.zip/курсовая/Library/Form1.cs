﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Library
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void pictureBoxClose_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void pictureBoxInfo_Click(object sender, EventArgs e)
        {

            MessageBox.Show("Данное приложение является информационной системой библиотеки.", "Информация");
        }

        private void buttonBooks_Click(object sender, EventArgs e)
        {
            FormBooks a = new FormBooks();
            a.Show();
            this.Hide();
        }

        private void buttonReaders_Click(object sender, EventArgs e)
        {
            FormReaders a = new FormReaders();
            a.Show();
            this.Hide();
        }

        private void buttonExtradition_Click(object sender, EventArgs e)
        {
            FormExtradition a = new FormExtradition();
            a.Show();
            this.Hide();
        }
    }
}
