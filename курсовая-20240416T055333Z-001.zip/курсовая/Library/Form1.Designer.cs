﻿
namespace Library
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.buttonBooks = new System.Windows.Forms.Button();
            this.buttonReaders = new System.Windows.Forms.Button();
            this.buttonExtradition = new System.Windows.Forms.Button();
            this.pictureBoxInfo = new System.Windows.Forms.PictureBox();
            this.pictureBoxClose = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxInfo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxClose)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // buttonBooks
            // 
            this.buttonBooks.BackColor = System.Drawing.SystemColors.Window;
            this.buttonBooks.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonBooks.Font = new System.Drawing.Font("Bookman Old Style", 20.25F);
            this.buttonBooks.Location = new System.Drawing.Point(52, 71);
            this.buttonBooks.Name = "buttonBooks";
            this.buttonBooks.Size = new System.Drawing.Size(178, 52);
            this.buttonBooks.TabIndex = 2;
            this.buttonBooks.Text = "Книги";
            this.buttonBooks.UseVisualStyleBackColor = false;
            this.buttonBooks.Click += new System.EventHandler(this.buttonBooks_Click);
            // 
            // buttonReaders
            // 
            this.buttonReaders.BackColor = System.Drawing.SystemColors.Window;
            this.buttonReaders.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonReaders.Font = new System.Drawing.Font("Bookman Old Style", 20.25F);
            this.buttonReaders.Location = new System.Drawing.Point(52, 190);
            this.buttonReaders.Name = "buttonReaders";
            this.buttonReaders.Size = new System.Drawing.Size(178, 52);
            this.buttonReaders.TabIndex = 3;
            this.buttonReaders.Text = "Читатели";
            this.buttonReaders.UseVisualStyleBackColor = false;
            this.buttonReaders.Click += new System.EventHandler(this.buttonReaders_Click);
            // 
            // buttonExtradition
            // 
            this.buttonExtradition.BackColor = System.Drawing.SystemColors.Window;
            this.buttonExtradition.Cursor = System.Windows.Forms.Cursors.Hand;
            this.buttonExtradition.Font = new System.Drawing.Font("Bookman Old Style", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonExtradition.Location = new System.Drawing.Point(52, 321);
            this.buttonExtradition.Name = "buttonExtradition";
            this.buttonExtradition.Size = new System.Drawing.Size(178, 52);
            this.buttonExtradition.TabIndex = 4;
            this.buttonExtradition.Text = "Операции";
            this.buttonExtradition.UseVisualStyleBackColor = false;
            this.buttonExtradition.Click += new System.EventHandler(this.buttonExtradition_Click);
            // 
            // pictureBoxInfo
            // 
            this.pictureBoxInfo.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxInfo.Image = global::Library.Properties.Resources.info;
            this.pictureBoxInfo.Location = new System.Drawing.Point(678, 13);
            this.pictureBoxInfo.Name = "pictureBoxInfo";
            this.pictureBoxInfo.Size = new System.Drawing.Size(47, 36);
            this.pictureBoxInfo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxInfo.TabIndex = 1;
            this.pictureBoxInfo.TabStop = false;
            this.pictureBoxInfo.Click += new System.EventHandler(this.pictureBoxInfo_Click);
            // 
            // pictureBoxClose
            // 
            this.pictureBoxClose.Cursor = System.Windows.Forms.Cursors.Hand;
            this.pictureBoxClose.Image = global::Library.Properties.Resources.ex;
            this.pictureBoxClose.Location = new System.Drawing.Point(741, 13);
            this.pictureBoxClose.Name = "pictureBoxClose";
            this.pictureBoxClose.Size = new System.Drawing.Size(47, 36);
            this.pictureBoxClose.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxClose.TabIndex = 0;
            this.pictureBoxClose.TabStop = false;
            this.pictureBoxClose.Click += new System.EventHandler(this.pictureBoxClose_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = global::Library.Properties.Resources.pushkin;
            this.pictureBox1.Location = new System.Drawing.Point(357, 53);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(313, 361);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 5;
            this.pictureBox1.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Window;
            this.BackgroundImage = global::Library.Properties.Resources.fon;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.buttonExtradition);
            this.Controls.Add(this.buttonReaders);
            this.Controls.Add(this.buttonBooks);
            this.Controls.Add(this.pictureBoxInfo);
            this.Controls.Add(this.pictureBoxClose);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxInfo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxClose)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBoxClose;
        private System.Windows.Forms.PictureBox pictureBoxInfo;
        private System.Windows.Forms.Button buttonBooks;
        private System.Windows.Forms.Button buttonReaders;
        private System.Windows.Forms.Button buttonExtradition;
        private System.Windows.Forms.PictureBox pictureBox1;
    }
}

